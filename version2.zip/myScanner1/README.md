# Lexical Analyzer in CSharp

### Compiler project - C# App that can analyze codes


![alt tag](https://github.com/yazdipour/Lexical_Analyzer_in_CSharp/blob/master/DFA.jpg)

### Steps to understand this proj

0. Run Analyzer.exe and have a look!
1. Understand DFA.jpg
2. Understand how matrix.txt works (Help:use matrixhelp.txt)
3. Read source code
4. and DONE!

