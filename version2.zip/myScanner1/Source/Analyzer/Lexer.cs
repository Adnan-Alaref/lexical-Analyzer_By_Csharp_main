﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Analyzer
{
    //Gui
    //Impelement the following match rule
    //Oprator +  | - | * | /..
    //Double oprator
    //Number [0-9]+
    //keyword
    //seprator
    //identifer

    class Lexer
    {
        const char PLUS = '+';
        const char MINUS = '-';
        const char MULTIPLICATION = '*';
        const char DIVISION = '/';
        const char DECIMAL_SEPERATOR = '.';
        const char OPEN_PAREN = '(';
        const char CLOSE_PAREN = ')';
        const char FACTORIAL = '!';
        const char EXPONENT = '^';

        static readonly char[] E_NOTATION = new char[] { 'e', 'E' }; //use in ISNext
        static readonly char[] SIGN_OPERATORS = new char[] { PLUS, MINUS };
     
        // map for single Oprator
        readonly static Dictionary<char, Func<int, char, Token>> OpratorMap =
            new Dictionary<char, Func<int, char, Token>>
            {
            {'-',(p,v)=> new Token(Token.TokenType.subtraction,p,v.ToString())},
            {'*',(p,v)=> new Token(Token.TokenType.Muliplacation,p,v.ToString()) },
            {'+',(p,v)=> new Token(Token.TokenType.Addation,p,v.ToString())},
            {'/',(p,v)=> new Token(Token.TokenType.Division,p,v.ToString())},
            {'^',(p,v)=> new Token(Token.TokenType.OS,p,v.ToString()) },
            {'%',(p,v)=> new Token(Token.TokenType.Moduls,p,v.ToString()) },
            {'=',(p,v)=> new Token(Token.TokenType.Assigen,p,v.ToString()) },
            {'!',(p,v)=> new Token(Token.TokenType.NotOprator,p,v.ToString()) },
            {'>',(p,v)=> new Token(Token.TokenType.GreateThan,p,v.ToString()) },
            {'<',(p,v)=> new Token(Token.TokenType.Lessthean,p,v.ToString()) },
            {'~',(p,v)=> new Token(Token.TokenType.converter,p,v.ToString()) },
            {'&',(p,v)=> new Token(Token.TokenType.AndBitWise,p,v.ToString()) },
            {'|',(p,v)=> new Token(Token.TokenType.OrBitWise,p,v.ToString()) },
            };

        // map for Double Oprator  ==,+=,-+,...
        readonly static Dictionary<string, Func<int, string, Token>> OpratorDoubleMap =
            new Dictionary<string, Func<int, string, Token>>
            {
            {"==",(p,v)=> new Token(Token.TokenType.OpratorDouble,p,v)},
            {">=",(p,v)=> new Token(Token.TokenType.OpratorDouble,p,v)},
            {"<=",(p,v)=> new Token(Token.TokenType.OpratorDouble,p,v)},
            {"!=",(p,v)=> new Token(Token.TokenType.OpratorDouble,p,v)},
            {"+=",(p,v)=> new Token(Token.TokenType.OpratorDouble,p,v)},
            {"-=",(p,v)=> new Token(Token.TokenType.OpratorDouble,p,v)},
            {"/=",(p,v)=> new Token(Token.TokenType.OpratorDouble,p,v)},
            {"++",(p,v)=> new Token(Token.TokenType.OpratorDouble,p,v)},
            {"--",(p,v)=> new Token(Token.TokenType.OpratorDouble,p,v)},
            {"*=",(p,v)=> new Token(Token.TokenType.OpratorDouble,p,v)},
            {"&=",(p,v)=> new Token(Token.TokenType.OpratorDouble,p,v)},
            {"|=",(p,v)=> new Token(Token.TokenType.OpratorDouble,p,v)},
            {"^=",(p,v)=> new Token(Token.TokenType.OpratorDouble,p,v)},
            {"<<",(p,v)=> new Token(Token.TokenType.OpratorDouble,p,v)},
            {">>",(p,v)=> new Token(Token.TokenType.OpratorDouble,p,v)},
            {"%=",(p,v)=> new Token(Token.TokenType.OpratorDouble,p,v)},
            };
        // map for single Sprator :,., ',' ,(,),{,},

        readonly static Dictionary<char, Func<int, char, Token>> SeparatorMap =
        new Dictionary<char, Func<int, char, Token>>
        {
            {':',(p,v)=> new Token(Token.TokenType.Separator,p,v.ToString())},
            {'.',(p,v)=> new Token(Token.TokenType.Separator,p,v.ToString())},
            {'(',(p,v)=> new Token(Token.TokenType.Separator,p,v.ToString())},
            {')',(p,v)=> new Token(Token.TokenType.Separator,p,v.ToString())},
            {'{',(p,v)=> new Token(Token.TokenType.Separator,p,v.ToString())},
            {'}',(p,v)=> new Token(Token.TokenType.Separator,p,v.ToString())},
            {'[',(p,v)=> new Token(Token.TokenType.Separator,p,v.ToString())},
            {']',(p,v)=> new Token(Token.TokenType.Separator,p,v.ToString())},
            {'@',(p,v)=> new Token(Token.TokenType.Separator,p,v.ToString())},
            {',',(p,v)=> new Token(Token.TokenType.Separator,p,v.ToString())},
            {';',(p,v)=> new Token(Token.TokenType.Separator,p,v.ToString())},

        };


        // map for reserved keyword
        readonly static Dictionary<string, int> KeyWordMap = new Dictionary<string, int> {
                { "abstract",1},{ "continue",1 },
                {"for",1 } ,{"new",1 } ,{"switch",1 },
                {"assert",1 } ,{"default",1 } ,{"if",1 }, {"package",1 }, {"synchronized" ,1},
                { "boolean" ,1} ,{"do",1 }, {"goto",1 } ,{"private",1 } ,{"this",1 },
                { "break",1 }, {"double",1 } ,{"implements",1 }, {"protected",1 }, {"throw",1 },
                {"byte",1 } ,{"else",1},{"import",1 } ,{"public",1 } ,{"throws",1 },
                {"case" ,1},{"enum",1 } ,{"instanceof",1} ,{"return",1 } ,{"transient",1 },
                {" catch",1 },{" extends",1 }, {"int",1 }, {"short",1 },{"try",1 },
                {"char",1 } ,{"final",1 },{"interface",1 } ,{"static",1 } ,{"void",1 },
                {" class",1 }, {"finally",1} ,{"long",1 } ,{"strictfp",1 }, {"volatile",1 },
                  {"const",1 }, {"float",1 } ,{"native" ,1} ,{"super",1 },{" while",1 },{" string",1 },
                  {"True",1 },{"False",1 },

        };
        readonly SourceScanner _scanner;
        public int Position => _scanner.Postion;
  
        public Lexer(SourceScanner sourceScanner) => _scanner = sourceScanner;

        public Token ReadNext()
        {
           
            if (_scanner.EndOFSource)
            {
                return new Token(Token.TokenType.EOF,_scanner.Postion,null);
               
            }

            // 1-Consume Line ans space
            ConsumeWhiteSpace();

            //write all function here 

            // 2-check double lignth oprator and out vat tolken decleare and also  pramters and not give to function
            if (TryTokenizeDoubleOprator(out var token))
                return token;

            if (TryTokenizeSingleLineComment(out token))
                return token; 
            if (TryTokenizeMultiLineComment(out token))
                return token;

            //3- check oprator and out vat tolken decleare and also  pramters and not give to function
            if (TryTokenizeOprator( out token))
                return token;
            // 4-check Sprator and out vat tolken decleare and also  pramters and not give to function
            if (TryTokenizSprator(out token))
                return token;
            //5-
            if (TryTokenizeNumber(out token))
                return token;
            //6- 
            if (TryTokenizeKyWord(out token))
                return token;
           //7-
            if (TryTokenizeIdentifer(out token))
                return token;
            //8- "   "
            if (TryTokenizeString(out token))
                return token;
            if (TryTokenizeChar(out token))
                return token;
            
            if (TryTokenizeUnicode(out token))
                return token;


            //end-return exception
            // throw new Exception($"UnExpected char {_scanner.Peek()} Found at this position {_scanner.Postion}");

            return new Token(Token.TokenType.ERROR,Position,"error");
        }
        //private bool TryTokenizeEndOFLine(out Token token)
        //{
        //    token = null;
        //    if ( _scanner.Peek() == ('\r') || _scanner.Peek() == ('\n') || _scanner.Peek(2) == ("\r\n"))
        //       _scanner.LineNumber++;
        //    return token != null;
        //}
        // return next token without move to  next token to check if EOF or not 
        public Token Peek() { 
            _scanner.Push();
           Token token = ReadNext();
            _scanner.Pop();
            return token;
        }
     
        private string ReadDigits()
        {
            var sb = new StringBuilder();
            // is digir is funcation take char return bool
            while (IsNext(char.IsDigit)) 
                sb.Append(Accept());
            return sb.ToString();
        }
        private char? Accept() => _scanner.Read();

        private void Expect(Predicate<char> match)
        {
            if (!IsNext(match))
                throw new Exception($"Unexpected value at position {Position}");
        }

        private bool IsNext(params char[] possibleValues)//take arry of varuble lengh
            => IsNext(x => possibleValues.Any(k => k == x));//call below isnext 
        //Predicate is adeleget function take char and rerurn true
        private bool IsNext(Predicate<char> match)
        {
            var lookahead = _scanner.Peek();
            return lookahead.HasValue && match(lookahead.Value);
        }
        
        // define single orator *, -,/+,^,|,&
        private bool TryTokenizeOprator(out  Token token)
        {
            token = null;
            var LookAhead = _scanner.Peek();
            if (LookAhead.HasValue && OpratorMap.ContainsKey(LookAhead.Value))
                token = OpratorMap[LookAhead.Value](Position,_scanner.Read().Value);

            return token != null;
        }
        //define double orator +=,-=,|=,&=,++,--...
        //must be above the TryTokenizeOprator in nextToken
        private bool TryTokenizeDoubleOprator(out Token token)
        {
            token = null;
            //peek return char and i want string
            string LookAhead = _scanner.Peek(2).ToString(); 
      
            if ( OpratorDoubleMap.ContainsKey(LookAhead))
            {
                token = OpratorDoubleMap[LookAhead.ToString()](_scanner.Postion, LookAhead.ToString());
                _scanner.Read();
                _scanner.Read();
            }

            return token != null;
        }

        //define double orator +=,-=,|=,&=,++,--...
        //must be above the TryTokenizeOprator in nextToken
        private bool TryTokenizeKyWord(out Token token)
        {
            token = null;
            if (_scanner.Peek().HasValue&&char.IsLetter(_scanner.Peek().Value))
            {
                //save start postion Of Numer to put him in Token
                var postion = _scanner.Postion;
                int cnt= 0;
                 //BuildeNumber
                var sb = new StringBuilder();
                //still concat digit and read while Peek is Digit
                while (_scanner.Peek().HasValue&& char.IsLetter(_scanner.Peek().Value))
                {
                    //apend currunt figit and read the next
                    sb.Append(_scanner.Read().Value);
                    cnt++;
                }
                if (KeyWordMap.ContainsKey(sb.ToString()))
                {
                    token = new Token(Token.TokenType.keyWord, postion, sb.ToString());
                }
                else _scanner.Pop(cnt);
            }
            return token != null;
        }
        //[,],(,),@,;, ',',.,:,
        private bool TryTokenizSprator(out Token token)
        {
            token = null;
            var LookAhead = _scanner.Peek();
            if (LookAhead.HasValue && SeparatorMap.ContainsKey(LookAhead.Value))
                token = SeparatorMap[LookAhead.Value](_scanner.Postion, _scanner.Read().Value);

            return token != null;
        }
        
        /// <summary>
            /// examples 1 100 1.5 .5 1e5 .1e5 1e-5
            ///   \d* .? \d+ ( [eE] [+-]? \d+ )?
            /// </summary>
            /// <param name="token"></param>
            /// <returns></returns>
        private bool TryTokenizeNumber(out Token token)
            {
                token = null;
                var sb = new StringBuilder();
                var position = Position;    //where did we start finding the digits


                // d*
                sb.Append(ReadDigits()); ;

                //.?
                if (IsNext(DECIMAL_SEPERATOR))
                {
                    sb.Append(Accept()); //accept the decimal
                }

                //\d +
                sb.Append(ReadDigits());

                //( [e E] [+ -]? \d+ )?
                if (sb.Length > 0 && char.IsDigit(sb[sb.Length - 1]) && IsNext(E_NOTATION))// to not strat with e , not start with .E
                {
                    sb.Append(Accept());         //accept the e

                    if (IsNext(SIGN_OPERATORS))
                    {    // accept + | -
                        sb.Append(Accept());
                    }
                    Expect(char.IsDigit);//must be E other throw exception
                    sb.Append(ReadDigits());
                }


                if (sb.Length > 0) //found something
                    token = new Token(Token.TokenType.Number, position, sb.ToString());

                if (token != null && !double.TryParse(token.Value, out _))
                    throw new Exception($"Invalid numeric value {token.Value} found at position {token.Postion}");

                return token != null;
            }

        //keyworde  must be above  TryTokenizidentifer
        private bool TryTokenizeIdentifer(out Token token)
        {
         
            token = null;
            var sb = new StringBuilder();
            var position = Position;

            if (IsNext('_'))
            {
                sb.Append(Accept());
                Expect(char.IsLetter);//is IsLetter is function take char and return bool
            }
            if (IsNext(char.IsLetter))
            {
                sb.Append(Accept()); //accept the letter
                while (IsNext(x => char.IsLetterOrDigit(x) || x == '_'))
                    sb.Append(Accept());
            }

            if (sb.Length > 0)
                token = new Token(Token.TokenType.Identifer, position, sb.ToString());
            return token != null;
        }
        bool IsOprator(char? c) =>OpratorMap.ContainsKey(c.Value);
        bool IsSeprator(char? c) => SeparatorMap.ContainsKey(c.Value);
        //String
        private bool TryTokenizeString(out Token token)
        {

            token = null;
            var sb = new StringBuilder();
            var position = Position;

            if (IsNext('"'))
            {
                Accept();
                while (_scanner.Peek()!='"'&& _scanner.Peek() != '\r' && _scanner.Peek() != '\n')
                {
                    if (IsNext('\\'))
                    {
                       sb.Append( Accept());
                        if (_scanner.Peek() == ' ')
                        {
                            Accept();
                            token = new Token(Token.TokenType.ERROR, position, "Error (:");  
                        }
                        else
                            sb.Append(Accept());
                    }
                    else 
                      sb.Append(Accept());
   
                }
                char? ch = ' ';
                if (_scanner.Peek() != null)
                    ch = Accept();
                if (ch == '\"' && _scanner.Peek() == '\"')
                {
                    Accept();
                    while (_scanner.Peek(3) != "\"\"\"")
                    {
                        sb.Append(Accept());
                    }
                    char? s1 = Accept();
                    char? s2 = Accept();
                    char? s3 = Accept();

                    if (s1 == '\"' && s2 == '\"' && s3 == '\"')
                        token = new Token(Token.TokenType.TextBlock, position, sb.ToString());
                }
                else
                {
                    if (ch == '"' && sb.Length == 0)
                        token = new Token(Token.TokenType.LitterialString, position, sb.ToString());

                    else if (token == null && ch == '"' && sb.Length > 0 && sb[sb.Length - 1] != '\\')
                        token = new Token(Token.TokenType.LitterialString, position, sb.ToString());
                }
                //char? ch=' ';
                //if(_scanner.Peek() !=null)
                // ch =Accept();

                //if (ch=='"'&&sb.Length==0)
                //    token = new Token(Token.TokenType.LitterialString, position, sb.ToString());

                //else if ( token==null&&ch=='"'&&sb.Length>0&&sb[sb.Length-1]!='\\')
                //    token = new Token(Token.TokenType.LitterialString, position, sb.ToString());
            }
            return token != null;
        }
        //SingleLineComment
        private bool TryTokenizeSingleLineComment(out Token token)
        {
            token = null;
            var sb = new StringBuilder();
            var position = Position;


            //single comment
            if (_scanner.Peek(2) == "//")
            {
                sb.Append(Accept()); sb.Append(Accept());
                while (!_scanner.EndOFSource && _scanner.Peek() != '\r' && _scanner.Peek() != '\n')
                {
                    sb.Append(Accept());
                }
                token = new Token(Token.TokenType.Comment, position, sb.ToString());
            }
            return token != null;
        }
        //multi line comment
        private bool TryTokenizeMultiLineComment(out Token token)
        {
            token = null;
            var sb = new StringBuilder();
            var position = Position;
            if (_scanner.Peek(2) == "/*")
            {
                sb.Append(Accept()); sb.Append(Accept());
                while (true)
                {
                    if (_scanner.Peek(2) == "*/")
                    {
                        sb.Append(Accept());
                        sb.Append(Accept());
                        if (_scanner.Peek(2) == "*/")
                        {
                            sb.Append(Accept()); sb.Append(Accept());
                            token = new Token(Token.TokenType.ERROR, position, sb.ToString());
                            break;
                        }
                        token = new Token(Token.TokenType.MultiComment, position, sb.ToString());
                        break;
                    }
                    else
                    {
                        sb.Append(Accept());
                    }
                }
            }
            return token != null;
        }
        //unicode
        private bool TryTokenizeUnicode(out Token token)
        {
            token = null;
            var sb = new StringBuilder();
            var position = Position;
            if (_scanner.Peek() == '\'')
            {
                sb.Append(Accept());
                if (_scanner.Peek(2) == "\\u")
                {
                    sb.Append(Accept());
                    sb.Append(Accept());
                    string unicode = "";
                    while (_scanner.Peek() != '\'' && _scanner.Peek() != '\r' && _scanner.Peek() != '\n')
                    {
                        unicode += _scanner.Peek();// 00ff'
                        sb.Append(Accept());
                    }
                    if (_scanner.Peek() == '\'')
                    {
                        sb.Append(Accept());
                        if (unicode.Length == 4)
                        {
                            string str = "abcdefABCDEF";
                            bool flag = true;
                            for (int i = 0; i < unicode.Length; i++)
                            {
                                if (char.IsDigit(unicode[i]) || str.Contains(unicode[i]))
                                {
                                    continue;
                                }
                                else
                                {
                                    token = new Token(Token.TokenType.ERROR, position, sb.ToString());
                                    flag = false;

                                }
                            }
                            if (flag)
                            {
                                token = new Token(Token.TokenType.Unicode, position, sb.ToString());
                            }

                        }
                        else
                        {
                            token = new Token(Token.TokenType.ERROR, position, sb.ToString());
                        }

                    }
                    else
                    {
                        token = new Token(Token.TokenType.ERROR, position, sb.ToString());
                    }

                }
            }
            return token != null;

        }
        //Literal Character
        private bool TryTokenizeChar(out Token token)
        {
            token = null;
           
            var sb = new StringBuilder();
            var position = Position;
            //string[] arr1 = { "\\t", "\\n","\'","\\","\"" };
            ////char?[] arr2 = { '\\', '\'', '\"', ' ' };

            if (_scanner.Peek()== '\'')
            {
                sb.Append(Accept());
                if (char.IsLetterOrDigit(_scanner.Peek().Value) || IsOprator(_scanner.Peek()) || IsSeprator(_scanner.Peek())|| _scanner.Peek()==' ')
                {
                    sb.Append(Accept());
                }
                else if (_scanner.Peek() == '\\')
                {
                
                    sb.Append(Accept());

                    if (_scanner.Peek() == '\\' || _scanner.Peek() == '\'' || _scanner.Peek() == '\"' || _scanner.Peek() == 't' || _scanner.Peek() == 'n')
                    {
                        sb.Append(Accept());
                    }
                }
   
                if (_scanner.Peek() == '\'')
                {
                    //char? c = Accept();
                    if(_scanner.Peek(2) == "\'\'")
                    {
                        sb.Append(Accept()); sb.Append(Accept());
                        token = new Token(Token.TokenType.ERROR, position, sb.ToString()); ;
                    }
                    else
                    {

                        if (sb.Length == 1)
                        {
                            sb.Append(Accept());
                            token = new Token(Token.TokenType.ERROR, position, sb.ToString());
                        }
                        else
                        {
                            sb.Append(Accept());
                            token = new Token(Token.TokenType.LiterialChar, position, sb.ToString());
                        }
                    }
                }
                else if(_scanner.Peek() != '\''|| _scanner.Peek() == '\r' || _scanner.Peek() == '\n')
                {
                    while ( _scanner.Peek() != '\r' && _scanner.Peek() != '\n')
                        sb.Append(Accept());
                    
                    token = new Token(Token.TokenType.ERROR, position, sb.ToString());
                }
            }
            return token != null;
        }



        //romove White space
        private void ConsumeWhiteSpace()//avoid space and line
        {
            while (IsNext(char.IsWhiteSpace))
                Accept();
        }

    }
}
