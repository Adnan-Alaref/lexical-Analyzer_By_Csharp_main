﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Analyzer
{
    class Token
    {

        // all kind of java keyword,sambole....
        public enum TokenType
        {
            EOL
            ,subtraction                 // -
            , Muliplacation               //*
            , Addation                    //+
            , Division                    //-
            , ERROR                       //ERROR
            ,EOF                         //end of file
            ,Number                      //[0-9]+
            , OS                          // ^
            ,  Moduls                      //%
            ,Assigen                       //=
            , NotOprator                     //!
            , GreateThan                  //>
            , Lessthean                    //<
            , converter                    //~
            , AndBitWise                   //&
            , OrBitWise                    //|
            , Separator                    // (,),[ ,],{,},:,@,
            , OpratorDouble                //+=,-=,*=,/=,&=,|=....
            , Identifer                   // x,y ....
            , keyWord                   //like int ,float,...
            , LitterialString            // " "
            , LiterialChar               // ' ' 
            , Comment                    //   
            , MultiComment               /**/   
            , Unicode                    // '\u00ff'
            , TextBlock                 // """            """
        }


        public TokenType Type;                  // kind of token
        public int Postion;                      //for id and number and sambol i but all token in sambol table not noly identifer  x=4
        public String Value;                    //for liem for  id
        //to set TokenKind and lexim  if the token  is identifer
        public Token(TokenType t, int p, String v) {
            Type = t;
            Postion = p;
            Value = v; 
        }

    
    }
}
