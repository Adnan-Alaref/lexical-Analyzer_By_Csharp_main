﻿using System;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace Analyzer {
    public partial class Form1 : Form {

        SymbolTable MySymbol=new SymbolTable();
        //to controle the Format of Sourcecode
       
     string loadBuffer(string text)
     {
           var source=new StringBuilder();
            foreach(var item in text.Split('\n'))
            {
                source.Append(item+'\n');
            }
            return source.ToString();
        }

        public Form1() {
            InitializeComponent();
        }
        //clear my inputText when buttom on  button2
        private void button2_Click(object sender,EventArgs e) {
            richTextBox1.Text = "";
        }

        private void button1_Click(object sender,EventArgs e) {
            //read sourse code from richTextBox1
            string intput = richTextBox1.Text;
            string SourceCode =loadBuffer(intput);

            //our token here
            string Output ="";
            //give my (lexcal)compiler  my source code
            var lexcar = new Lexer(new SourceScanner(SourceCode));

            //-index in sambole table
            int cnt = 0;
            //read  until reatch to  Ene of file Type
            while (lexcar.Peek().Type != Token.TokenType.EOF)
            {
                //searche for new token 
                Token token = lexcar.ReadNext();
                if (token.Type != Token.TokenType.EOL)
                    MySymbol.AddOrUpdate(token.Value,++cnt,token.Type.ToString());
                // concate token
               if(token.Type!=Token.TokenType.EOL)
                Output+=($"<<{token.Value}   Position => {token.Postion}   type => {token.Type}   " +
                    $"postion at mySymbol => {MySymbol.Get(token.Value).postion} >>\n").ToString();
               

            }
            // show the all token on richTextBox2
            richTextBox2.Text = Output;

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
