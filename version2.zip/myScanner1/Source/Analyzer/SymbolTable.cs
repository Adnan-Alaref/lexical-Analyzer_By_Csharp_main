﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace Analyzer
{

    public  class SymbolTableEntry {

        public enum EntryType {
            Variable,
            Function,
       
        }

        public string IdentiferName { get; }
        public string Type { get; }
        public int postion { get; }
        public SymbolTableEntry( string name, int poistion, string entryType ) {
            IdentiferName = name;
            Type = entryType;
           this.postion=poistion;
        }
    }


    public class SymbolTable {

        readonly Dictionary<string, SymbolTableEntry> Entries = new Dictionary<string, SymbolTableEntry>();

      
        public void AddOrUpdate( string identifier,int poistion, string type) {
            if( !Entries.ContainsKey( identifier ) ) {

                Entries.Add( identifier, new SymbolTableEntry( identifier,poistion, type) );
            } 
        }

        public SymbolTableEntry Get( string idenifierName )
            => Entries.ContainsKey( idenifierName )
            ? Entries[ idenifierName ] : null;

    }
}
