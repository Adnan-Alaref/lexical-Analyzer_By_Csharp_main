﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Analyzer
{
    class SourceScanner
    {
        // to save my current posation when move to next
        readonly Stack<int> _postionStack = new Stack<int>();
        //All SourceCode
        readonly string _buffer;                    
       // currnt poition in mybuffer
        public int Postion { get; private set; }
        public int LineNumber { get;  set; }
        //fuction to Know the rnd of Source code
        public bool EndOFSource => Postion >= _buffer.Length;   

        //read current posion and move to next positon
        public char? Read()=>(EndOFSource? (char?) null:_buffer[Postion++]); 
        //constactor and source code as paramter
        public SourceScanner(string expression)=> _buffer = expression;    

        // reat current  posiotion without move to next
        public char? Peek()    
        {
            Push();
            char? next = Read();
            Pop();
            return next;
        }
        //take some chare whithout move to next
        public string Peek(int n)
        {
            string next="";
            for (int i = 0; i < n; i++)
            {
                Push();
                next += Read().ToString();
            }
            for (int i = 0; i< n; i++)
            Pop();

            return next;
        }
        //push and pop use in peek function

        //push current posoition at top of  stack
        public void Push() => _postionStack.Push(Postion);
        //pop current posoition from top of  stack and make location equal him 
        public void Pop() => Postion=_postionStack.Pop();
        public void Pop(int n)
        {
            for (int i = 0; i < n; i++)
                Postion--;
        }

    }
}
